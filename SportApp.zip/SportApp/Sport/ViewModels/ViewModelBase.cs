﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Sport.ViewModels;

public class ViewModelBase : ObservableObject
{
}
