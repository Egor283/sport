﻿using Avalonia.Controls;
using Sport.Classes;

namespace Sport.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        Help.MainWnd = this;
    }
}
