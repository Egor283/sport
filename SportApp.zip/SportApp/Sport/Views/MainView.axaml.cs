﻿using Avalonia.Controls;
using Microsoft.EntityFrameworkCore;
using MsBox.Avalonia;
using Sport.Classes;
using Sport.Data;
using System.Linq;

namespace Sport.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
        loadSportTypes();
        LoadData();
    }

    private void LoadData()
    {
        Help.SDT.Sportsmen.Load();
        Help.SDT.Coaches.Load();

        if (SportTypeCb.SelectedIndex == 0)
        {
            SportsmanDG.ItemsSource = Help.SDT.Sportsmen.ToList();
            CoachDG.ItemsSource = Help.SDT.Coaches.ToList();
        }
        else
        {
            var selected = SportTypeCb.SelectedItem as Sporttype;
            SportsmanDG.ItemsSource = Help.SDT.Sportsmen.Where(el => el.Coach.Sporttypeid == selected.Id).ToList();
            CoachDG.ItemsSource = Help.SDT.Coaches.Where(el => el.Sporttypeid == selected.Id).ToList();
        }
    }

    private void loadSportTypes()
    {
        Help.SDT.Sporttypes.Load();

        var sportTypes = Help.SDT.Sporttypes.ToList();
        sportTypes.Insert(0, new Sporttype() { Name = "Все" });
        SportTypeCb.ItemsSource = sportTypes;
        SportTypeCb.SelectedIndex = 0;
    }

    private void ComboBox_SelectionChanged(object? sender, Avalonia.Controls.SelectionChangedEventArgs e)
    {
        LoadData();
    }

    private async void Button_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        AddSportsmanWindow wnd = new AddSportsmanWindow();
        await wnd.ShowDialog(Help.MainWnd);
        LoadData();
    }

    private async void Button_Click1(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (SportsmanDG.SelectedItem != null)
        {
            var selected = SportsmanDG.SelectedItem as Sportsman;
            AddSportsmanWindow wnd = new AddSportsmanWindow(selected.Id);
            await wnd.ShowDialog(Help.MainWnd);
            LoadData();
        }
    }

    private async void Button_Click2(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (SportsmanDG.SelectedItem != null)
        {
            var selected = SportsmanDG.SelectedItem as Sportsman;
            var result = await MessageBoxManager.GetMessageBoxStandard("Удаление", "Вы хотите удалить спортсмена?",
                MsBox.Avalonia.Enums.ButtonEnum.YesNo, MsBox.Avalonia.Enums.Icon.Question).ShowWindowDialogAsync(Help.MainWnd);
            if (result == MsBox.Avalonia.Enums.ButtonResult.Yes)
            {
                Help.SDT.Sportsmen.Remove(selected);
                Help.SDT.SaveChanges();
            }
            LoadData();
        }
    }
}
