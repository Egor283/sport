using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using Microsoft.EntityFrameworkCore;
using Sport.Classes;
using Sport.Data;
using System.Linq;

namespace Sport;

public partial class AddSportsmanWindow : Window
{
    private int _id = -1;
    public AddSportsmanWindow(int id = -1)
    {
        InitializeComponent();
        _id = id;
        loadData();
    }

    private void loadData()
    {
        Help.SDT.Coaches.Load();
        CoachCb.ItemsSource = Help.SDT.Coaches.ToList();
        if (_id == -1)
        {
            MainSp.DataContext = new Sportsman();
            CoachCb.SelectedIndex = 0;
        }
        else
        {
            Help.SDT.Sportsmen.Load();
            MainSp.DataContext = Help.SDT.Sportsmen.FirstOrDefault(el => el.Id == _id);
        }
    }

    private void Button_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (_id == -1)
        {
            var sportsman = MainSp.DataContext as Sportsman;
            Help.SDT.Sportsmen.Add(sportsman);
        }

        Help.SDT.SaveChanges();
        Close();
    }
    private void Button_Click1(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        Close();
    }
}