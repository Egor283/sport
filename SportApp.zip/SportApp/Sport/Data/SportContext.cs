﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Scaffolding.Internal;

namespace Sport.Data;

public partial class SportContext : DbContext
{
    public SportContext()
    {
    }

    public SportContext(DbContextOptions<SportContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Coach> Coaches { get; set; }

    public virtual DbSet<Sportsman> Sportsmen { get; set; }

    public virtual DbSet<Sporttype> Sporttypes { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("server=127.0.0.1;uid=root;database=sport;pwd=1234", Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.41-mysql"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_0900_ai_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<Coach>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("coach");

            entity.HasIndex(e => e.Sporttypeid, "sporttypeid_idx");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Name)
                .HasMaxLength(45)
                .HasColumnName("name");
            entity.Property(e => e.Sporttypeid).HasColumnName("sporttypeid");

            entity.HasOne(d => d.Sporttype).WithMany(p => p.Coaches)
                .HasForeignKey(d => d.Sporttypeid)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("sporttypeid");
        });

        modelBuilder.Entity<Sportsman>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("sportsman");

            entity.HasIndex(e => e.Coachid, "coachid_idx");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Coachid).HasColumnName("coachid");
            entity.Property(e => e.Name)
                .HasMaxLength(45)
                .HasColumnName("name");

            entity.HasOne(d => d.Coach).WithMany(p => p.Sportsmen)
                .HasForeignKey(d => d.Coachid)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("coachid");
        });

        modelBuilder.Entity<Sporttype>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("sporttype");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Name)
                .HasMaxLength(45)
                .HasColumnName("name");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
