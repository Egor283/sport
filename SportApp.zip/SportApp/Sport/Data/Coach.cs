﻿using System;
using System.Collections.Generic;

namespace Sport.Data;

public partial class Coach
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public int Sporttypeid { get; set; }

    public virtual ICollection<Sportsman> Sportsmen { get; set; } = new List<Sportsman>();

    public virtual Sporttype Sporttype { get; set; } = null!;
}
