﻿using System;
using System.Collections.Generic;

namespace Sport.Data;

public partial class Sporttype
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public virtual ICollection<Coach> Coaches { get; set; } = new List<Coach>();
}
