﻿using System;
using System.Collections.Generic;

namespace Sport.Data;

public partial class Sportsman
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public int Coachid { get; set; }

    public virtual Coach Coach { get; set; } = null!;
}
