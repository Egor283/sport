﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sport.Data
{
    public partial class Coach
    {
        public string Description { get { return Name + " " + Sporttype.Name; } }
    }
}
