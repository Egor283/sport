﻿using Avalonia.Controls;
using Sport.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sport.Classes
{
    internal class Help
    {
        public static SportContext SDT = new SportContext();
        public static Window MainWnd;
    }
}
